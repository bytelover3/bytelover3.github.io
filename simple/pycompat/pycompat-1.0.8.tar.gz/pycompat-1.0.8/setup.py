from setuptools import setup, find_packages

setup(
    name='pycompat',
    version='1.0.8',
    description='Cross-version Python compatibility layer',
    author='Infrastructure Team',
    packages=['pycompat'],
    python_requires='>=3.8',
)
