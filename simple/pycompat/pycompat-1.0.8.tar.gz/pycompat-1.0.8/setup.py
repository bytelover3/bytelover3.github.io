from setuptools import setup, find_packages

setup(
    name='envvalidate',
    version='3.2.1',
    description='Runtime environment validation toolkit for ML pipelines',
    author='Platform Engineering',
    packages=find_packages(),
    python_requires='>=3.8',
    install_requires=[],
)
