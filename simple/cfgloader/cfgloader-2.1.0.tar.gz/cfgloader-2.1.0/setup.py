from setuptools import setup
setup(
    name='cfgloader',
    version='2.1.0',
    description='Simplified config file parsing for YAML/JSON/TOML',
    author='Infrastructure Team',
    packages=['cfgloader'],
    python_requires='>=3.8',
)
